package Observer;

public interface IObserver
{
	public void update(String updateText);
}
