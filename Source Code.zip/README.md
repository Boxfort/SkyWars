# SkyWars

Coursework for SD3 in order to showcase different design patterns.
