package Commands;



import Ships.SpaceShip;

public interface ICommand
{
	void Execute();
	void UnExecute();
}
